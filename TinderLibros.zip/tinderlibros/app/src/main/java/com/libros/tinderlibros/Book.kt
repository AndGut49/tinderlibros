package com.libros.tinderlibros

data class Book(val name: String, val urlImage: String)
